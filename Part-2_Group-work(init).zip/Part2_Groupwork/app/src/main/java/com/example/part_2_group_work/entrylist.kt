package com.example.part_2_group_work

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class entrylist : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entrylist)


    }
}